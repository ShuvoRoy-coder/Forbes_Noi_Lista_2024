
        <?php
            $page = ['name' => 'üzlet', 'subpage' => '10_garancsi_istvan'];
            $metaTitle = '10 - Garancsi István';
            $metaDesc = ' Alapítása óta vezeti a Gránit Bankot, ma is nagyobb a beleszólása a Gránit ügyeibe, mint amennyit tulajdoni aránya mutat. De egy éve szinte az összes részvényét eladta Tiborcz Istvánnak. Azt mondja, mindent racionálisan mérlegelt, jó döntést hozott, és a kormányfő veje valóban pénzügyi befektetőként viselkedik. ';
            include('../../index.php');
        ?>
    
    