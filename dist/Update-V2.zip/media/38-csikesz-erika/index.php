
        <?php
            $page = ['name' => 'media', 'subpage' => '38-csikesz-erika'];
            $metaTitle = '#38 - Csikesz Erika';
            include('../../index.php');
        ?>
    
    