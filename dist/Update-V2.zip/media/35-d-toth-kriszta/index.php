
        <?php
            $page = ['name' => 'media', 'subpage' => '35-d-toth-kriszta'];
            $metaTitle = '#35 - D. Tórh Kriszta';
            include('../../index.php');
        ?>
    
    