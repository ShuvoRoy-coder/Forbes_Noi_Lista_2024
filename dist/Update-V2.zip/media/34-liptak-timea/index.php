
        <?php
            $page = ['name' => 'media', 'subpage' => '34-liptak-timea'];
            $metaTitle = '#34 - Lipták Tímea';
            include('../../index.php');
        ?>
    
    