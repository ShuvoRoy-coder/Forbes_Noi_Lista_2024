
        <?php
            $page = ['name' => 'media', 'subpage' => '39-varkonyi-andrea'];
            $metaTitle = '#39 - Várkonyi Andrea';
            include('../../index.php');
        ?>
    
    