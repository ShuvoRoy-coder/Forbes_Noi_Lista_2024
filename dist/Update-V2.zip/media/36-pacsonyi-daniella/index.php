
        <?php
            $page = ['name' => 'media', 'subpage' => '36-pacsonyi-daniella'];
            $metaTitle = '#36 - Pácsonyi Daniella';
            include('../../index.php');
        ?>
    
    