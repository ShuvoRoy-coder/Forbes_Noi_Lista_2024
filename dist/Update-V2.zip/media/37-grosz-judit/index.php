
        <?php
            $page = ['name' => 'media', 'subpage' => '37-grosz-judit'];
            $metaTitle = '#37 - Grósz Judit';
            include('../../index.php');
        ?>
    
    