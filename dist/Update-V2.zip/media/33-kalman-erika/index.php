
        <?php
            $page = ['name' => 'media', 'subpage' => '33-kalman-erika'];
            $metaTitle = '#33 - Kálmán Erika';
            include('../../index.php');
        ?>
    
    