
        <?php
            $page = ['name' => 'media', 'subpage' => '40-hamori-gabriella'];
            $metaTitle = '#40 - Hámori Gabriella';
            include('../../index.php');
        ?>
    
    