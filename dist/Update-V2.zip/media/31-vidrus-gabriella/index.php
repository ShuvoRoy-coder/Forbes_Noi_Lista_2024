
        <?php
            $page = ['name' => 'media', 'subpage' => '31-vidrus-gabriella'];
            $metaTitle = '#31 - Vidus Gabriella';
            include('../../index.php');
        ?>
    
    