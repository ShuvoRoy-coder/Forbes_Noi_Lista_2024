
        <?php
            $page = ['name' => 'uzlet-nemzetkozi', 'subpage' => '16-orban-anita'];
            $metaTitle = '#16 - Orbán Anita';
            include('../../index.php');
        ?>
    
    