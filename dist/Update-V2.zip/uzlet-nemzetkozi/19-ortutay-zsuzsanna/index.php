
        <?php
            $page = ['name' => 'uzlet-nemzetkozi', 'subpage' => '19-ortutay-zsuzsanna'];
            $metaTitle = '#19 - Ortutay Zsuzsanna';
            include('../../index.php');
        ?>
    
    