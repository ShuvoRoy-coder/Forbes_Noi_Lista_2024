
        <?php
            $page = ['name' => 'uzlet-nemzetkozi', 'subpage' => '18-wortmann-gabriella'];
            $metaTitle = '#18 - Wortmann Gabriella';
            include('../../index.php');
        ?>
    
    