
        <?php
            $page = ['name' => 'uzlet-nemzetkozi', 'subpage' => '17-szabo-melinda'];
            $metaTitle = '#17 - Szabó Melinda';
            include('../../index.php');
        ?>
    
    