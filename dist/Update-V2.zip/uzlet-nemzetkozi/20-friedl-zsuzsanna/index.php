
        <?php
            $page = ['name' => 'uzlet-nemzetkozi', 'subpage' => '20-friedl-zsuzsanna'];
            $metaTitle = '#20 - Friedl Zsuzsanna';
            include('../../index.php');
        ?>
    
    