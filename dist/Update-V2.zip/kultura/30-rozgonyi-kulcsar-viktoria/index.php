
        <?php
            $page = ['name' => 'kultura', 'subpage' => '30-rozgonyi-kulcsar-viktoria'];
            $metaTitle = '#30 - Rozgonyi-Kulcsár Viktória';
            include('../../index.php');
        ?>
    
    