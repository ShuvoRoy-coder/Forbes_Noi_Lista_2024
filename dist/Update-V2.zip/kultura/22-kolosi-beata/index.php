
        <?php
            $page = ['name' => 'kultura', 'subpage' => '22-kolosi-beata'];
            $metaTitle = '#22 - Kolosi Beáta';
            include('../../index.php');
        ?>
    
    