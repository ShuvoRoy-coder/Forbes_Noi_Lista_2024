
        <?php
            $page = ['name' => 'kultura', 'subpage' => '26-enyedi-ildiko'];
            $metaTitle = '#26 - Enyedi Ildikó';
            include('../../index.php');
        ?>
    
    