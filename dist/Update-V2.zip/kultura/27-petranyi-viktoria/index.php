
        <?php
            $page = ['name' => 'kultura', 'subpage' => '27-petranyi-viktoria'];
            $metaTitle = '#27 - Petrányi Viktória';
            include('../../index.php');
        ?>
    
    