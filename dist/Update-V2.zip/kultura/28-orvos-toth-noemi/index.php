
        <?php
            $page = ['name' => 'kultura', 'subpage' => '28-orvos-toth-noemi'];
            $metaTitle = '#28 - Orvos-Tórh Noémi';
            include('../../index.php');
        ?>
    
    