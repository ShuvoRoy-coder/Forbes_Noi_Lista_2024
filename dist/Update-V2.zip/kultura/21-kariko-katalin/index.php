
        <?php
            $page = ['name' => 'kultura', 'subpage' => '21-kariko-katalin'];
            $metaTitle = '#21 - Karikó Katalin';
            include('../../index.php');
        ?>
    
    