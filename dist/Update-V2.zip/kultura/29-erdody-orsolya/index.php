
        <?php
            $page = ['name' => 'kultura', 'subpage' => '29-erdody-orsolya'];
            $metaTitle = '#29 - Erdődy Orsolya';
            include('../../index.php');
        ?>
    
    