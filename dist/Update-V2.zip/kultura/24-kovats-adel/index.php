
        <?php
            $page = ['name' => 'kultura', 'subpage' => '24-kovats-adel'];
            $metaTitle = '#24 - Kováts Adél';
            include('../../index.php');
        ?>
    
    