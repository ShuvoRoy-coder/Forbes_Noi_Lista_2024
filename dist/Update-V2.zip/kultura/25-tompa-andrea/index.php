
        <?php
            $page = ['name' => 'kultura', 'subpage' => '25-tompa-andrea'];
            $metaTitle = '#25 - Tompa Andrea';
            include('../../index.php');
        ?>
    
    