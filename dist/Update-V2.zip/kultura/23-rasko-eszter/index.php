
        <?php
            $page = ['name' => 'kultura', 'subpage' => '23-rasko-eszter'];
            $metaTitle = '#23 - Ráskó Eszter';
            include('../../index.php');
        ?>
    
    