
        <?php
            $page = ['name' => 'uzlet', 'subpage' => '2-balogh-gabriella'];
            $metaTitle = '#2 - Balogh Gabriella';
            include('../../index.php');
        ?>
    
    