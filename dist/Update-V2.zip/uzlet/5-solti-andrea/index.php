
        <?php
            $page = ['name' => 'uzlet', 'subpage' => '5-solti-andrea'];
            $metaTitle = '#5 - Solti Andrea';
            include('../../index.php');
        ?>
    
    