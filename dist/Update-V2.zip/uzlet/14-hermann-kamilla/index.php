
        <?php
            $page = ['name' => 'uzlet', 'subpage' => '14-hermann-kamilla'];
            $metaTitle = '#14 - Herman Kamilla';
            include('../../index.php');
        ?>
    
    