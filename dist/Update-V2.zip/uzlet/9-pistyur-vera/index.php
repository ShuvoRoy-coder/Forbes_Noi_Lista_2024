
        <?php
            $page = ['name' => 'uzlet', 'subpage' => '9-pistyur-vera'];
            $metaTitle = '#9 - Pistyur Vera';
            include('../../index.php');
        ?>
    
    