
        <?php
            $page = ['name' => 'uzlet', 'subpage' => '15-varga-eszter'];
            $metaTitle = '#15 - Varga Eszter';
            include('../../index.php');
        ?>
    
    