
        <?php
            $page = ['name' => 'uzlet', 'subpage' => '6-heiszler-gabriella'];
            $metaTitle = '#6 - Heiszler Gabriella';
            include('../../index.php');
        ?>
    
    