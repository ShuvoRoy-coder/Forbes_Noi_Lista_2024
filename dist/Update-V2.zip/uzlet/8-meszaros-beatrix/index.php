
        <?php
            $page = ['name' => 'uzlet', 'subpage' => '8-meszaros-beatrix'];
            $metaTitle = '#8 - Mészáros Beatrix';
            include('../../index.php');
        ?>
    
    