
        <?php
            $page = ['name' => 'uzlet', 'subpage' => '11-blasko-nikoletta'];
            $metaTitle = '#11 - Blaskó Nikoletta';
            include('../../index.php');
        ?>
    
    