
        <?php
            $page = ['name' => 'uzlet', 'subpage' => '7-czako-borbala'];
            $metaTitle = '#7 - Czakó Borbála';
            include('../../index.php');
        ?>
    
    