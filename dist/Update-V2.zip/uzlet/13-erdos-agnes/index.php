
        <?php
            $page = ['name' => 'uzlet', 'subpage' => '13-erdos-agnes'];
            $metaTitle = '#13 - Erdős Ágnes';
            include('../../index.php');
        ?>
    
    