
        <?php
            $page = ['name' => 'uzlet', 'subpage' => '3-walter-katalin'];
            $metaTitle = '#3 - Walter Katalin';
            include('../../index.php');
        ?>
    
    