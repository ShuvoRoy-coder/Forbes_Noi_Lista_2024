
        <?php
            $page = ['name' => 'uzlet', 'subpage' => '10-fabian-agnes'];
            $metaTitle = '#10 - Fábián Ágnes';
            include('../../index.php');
        ?>
    
    