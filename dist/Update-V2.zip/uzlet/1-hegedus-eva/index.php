
        <?php
            $page = ['name' => 'uzlet', 'subpage' => '1-hegedus-eva'];
            $metaTitle = '#1 - Hegedűs Éva';
            include('../../index.php');
        ?>
    
    