
        <?php
            $page = ['name' => 'uzlet', 'subpage' => '12-liptay-gabriella'];
            $metaTitle = '#12 - Liptay Gabriella';
            include('../../index.php');
        ?>
    
    