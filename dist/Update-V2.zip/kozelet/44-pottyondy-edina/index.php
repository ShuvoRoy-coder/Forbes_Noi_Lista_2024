
        <?php
            $page = ['name' => 'kozelet', 'subpage' => '44-pottyondy-edina'];
            $metaTitle = '#44 - Pottyondy Edina';
            include('../../index.php');
        ?>
    
    