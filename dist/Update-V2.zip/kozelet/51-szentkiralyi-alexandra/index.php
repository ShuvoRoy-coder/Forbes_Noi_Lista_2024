
        <?php
            $page = ['name' => 'kozelet', 'subpage' => '51-szentkiralyi-alexandra'];
            $metaTitle = '#51 - Szentkirályi Alexandra';
            include('../../index.php');
        ?>
    
    