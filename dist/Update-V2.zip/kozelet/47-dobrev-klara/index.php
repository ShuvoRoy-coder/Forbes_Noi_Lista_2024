
        <?php
            $page = ['name' => 'kozelet', 'subpage' => '47-dobrev-klara'];
            $metaTitle = '#47 - Dobrev Klára';
            include('../../index.php');
        ?>
    
    