
        <?php
            $page = ['name' => 'kozelet', 'subpage' => '50-pardavi-marta'];
            $metaTitle = '#50 - Pardavi Márta';
            include('../../index.php');
        ?>
    
    