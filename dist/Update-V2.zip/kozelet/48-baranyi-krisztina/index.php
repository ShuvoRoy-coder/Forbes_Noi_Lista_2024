
        <?php
            $page = ['name' => 'kozelet', 'subpage' => '48-baranyi-krisztina'];
            $metaTitle = '#48 - Baranyi Krisztina';
            include('../../index.php');
        ?>
    
    