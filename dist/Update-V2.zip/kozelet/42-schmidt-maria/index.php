
        <?php
            $page = ['name' => 'kozelet', 'subpage' => '42-schmidt-maria'];
            $metaTitle = '#42 - Schmidt Mária';
            include('../../index.php');
        ?>
    
    