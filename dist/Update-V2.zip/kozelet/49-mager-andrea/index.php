
        <?php
            $page = ['name' => 'kozelet', 'subpage' => '49-mager-andrea'];
            $metaTitle = '#49 - Mager Andrea';
            include('../../index.php');
        ?>
    
    