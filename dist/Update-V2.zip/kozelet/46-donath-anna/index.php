
        <?php
            $page = ['name' => 'kozelet', 'subpage' => '46-donath-anna'];
            $metaTitle = '#46 - Donáth Anna';
            include('../../index.php');
        ?>
    
    