
        <?php
            $page = ['name' => 'kozelet', 'subpage' => '45-duro-dora'];
            $metaTitle = '#45 - Dúró Dóra';
            include('../../index.php');
        ?>
    
    