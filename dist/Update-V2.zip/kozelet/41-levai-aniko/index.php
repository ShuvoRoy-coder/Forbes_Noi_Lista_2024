
        <?php
            $page = ['name' => 'kozelet', 'subpage' => '41-levai-aniko'];
            $metaTitle = '#41 - Lévai Anikó';
            include('../../index.php');
        ?>
    
    