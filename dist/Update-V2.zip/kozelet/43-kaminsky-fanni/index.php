
        <?php
            $page = ['name' => 'kozelet', 'subpage' => '43-kaminsky-fanni'];
            $metaTitle = '#43 - Kaminski Fanny';
            include('../../index.php');
        ?>
    
    